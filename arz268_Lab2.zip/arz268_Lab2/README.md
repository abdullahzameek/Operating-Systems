## Two Pass Linker

For this assignment, I used Python3. 
There is no compilation process for this program. 
To run it on crackle1, you have to invoke python3 explicitly by typing:

python3 scheduler.py <pathToInputFile>

An example would be 

python3 scheduler.py inputs/input-7.txt 


Additionally, it accepts a verbose argument as follows:

python3 scheduler.py --verbose <pathToInputFile>

An example would be

python3 scheduler.py --verbose inputs/input-7.txt 

