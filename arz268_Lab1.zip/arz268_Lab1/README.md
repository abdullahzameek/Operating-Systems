## Two Pass Linker

For this assignment, I used Python3. 
There is no compilation process for this program. 
To run it on crackle1, you have to invoke python3 explicitly by typing:

python3 linker.py

To get the input you may simply type in the input after typing python3 linker.py
After typing the input, hit the enter key and CTRL+D to indicate the end of standard input.
Alternatively, the easier method to input text would be to save the input in a text file and
pipe it into the program. This can be done like so :

cat input-X | python3 linker.py

where X is the number of the input file.